# [gsap/slideshow] ❍ Vertical Zoom Slideshow N°2

A Pen created on CodePen.

Original URL: [https://codepen.io/filipz/pen/NPWQZya](https://codepen.io/filipz/pen/NPWQZya).

